# مصاريفي — تحويلها لتطبيق موبايل (أندرويد + آيفون)

## الطريقة 1: PWA (الأسهل، من غير متجر، مجانًا)

1. ارفع محتوى الفولدر ده كله على أي استضافة HTTPS مجانية:
   - Netlify: ادخل netlify.com/drop واسحب الفولدر.
   - أو GitHub Pages أو Cloudflare Pages.
2. افتح الرابط على الموبايل:
   - **أندرويد (Chrome):** القائمة ⋮ ← «تثبيت التطبيق» / «إضافة إلى الشاشة الرئيسية».
   - **آيفون (Safari):** زرار المشاركة ← «إضافة إلى الشاشة الرئيسية».
3. هتلاقي «مصاريفي» أيقونة على الشاشة، بتفتح بملء الشاشة وبتشتغل من غير نت.

> لازم HTTPS، ولو فتحت الملف مباشرة من الموبايل الـ PWA مش هيتثبّت.

## الطريقة 2: تطبيق حقيقي (APK / IPA) بـ Capacitor

محتاج Node.js على الكمبيوتر، وAndroid Studio للأندرويد، وماك + Xcode للآيفون.

```bash
mkdir masrofi-app && cd masrofi-app
npm init -y
npm i @capacitor/core @capacitor/cli @capacitor/android @capacitor/ios
npx cap init "مصاريفي" com.masrofi.app --web-dir=www
mkdir www && cp -r ../masrofi-pwa/* www/
npx cap add android
npx cap add ios
npx cap sync
npx cap open android   # ← Build > Build APK
npx cap open ios       # ← Archive من Xcode
```

لنشر على Google Play محتاج حساب مطوّر (25$ مرة واحدة)، وعلى App Store (99$ في السنة).

## ملاحظات مهمة

- **الخطوط:** البرنامج بيحمّل خط IBM Plex Sans Arabic من Google Fonts. من غير نت أول مرة هيستخدم خط النظام. لو عايز الخط يشتغل أوفلاين 100% نزّل ملفات الخط وحطها جوه الفولدر.
- **البيانات:** بتتخزن على الجهاز نفسه (localStorage). لو مسحت بيانات المتصفح/التطبيق هتضيع، فاعمل نسخة احتياطية.
- **البصمة:** بتشتغل في PWA على HTTPS. جوه Capacitor ممكن تحتاج إضافة plugin للبصمة.
